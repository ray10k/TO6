var searchData=
[
  ['latency',['Latency',['../latency.html',1,'']]]
];
