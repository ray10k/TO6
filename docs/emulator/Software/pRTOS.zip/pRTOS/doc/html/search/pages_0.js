var searchData=
[
  ['compile_2dtime_20configuration',['Compile-time configuration',['../configuration.html',1,'']]]
];
