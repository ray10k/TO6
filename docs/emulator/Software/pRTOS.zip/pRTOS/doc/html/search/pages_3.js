var searchData=
[
  ['non_2dpreemptive_20task_20switching',['Non-preemptive task switching',['../non-preemptive.html',1,'']]]
];
