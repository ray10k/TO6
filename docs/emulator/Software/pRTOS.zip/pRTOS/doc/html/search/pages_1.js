var searchData=
[
  ['debug_20logging_20support',['Debug logging support',['../debug.html',1,'']]]
];
