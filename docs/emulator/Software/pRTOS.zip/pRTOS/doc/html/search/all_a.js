var searchData=
[
  ['read',['read',['../class_r_t_o_s_1_1pool.html#a0ef6382b71ae141cf38f477c8bfea325',1,'RTOS::pool::read()'],['../class_r_t_o_s_1_1mailbox.html#af2bc862b64929b5ec34afa4dec0ed720',1,'RTOS::mailbox::read()'],['../class_r_t_o_s_1_1channel.html#a66da852f3e9ef72066e5f582f4c2f218',1,'RTOS::channel::read()']]],
  ['release',['release',['../class_r_t_o_s_1_1task.html#aa3eec7220a2724d30e2156cc395035f2',1,'RTOS::task']]],
  ['resume',['resume',['../class_r_t_o_s_1_1task.html#a841b14aaab18d883959f034510dd9376',1,'RTOS::task']]],
  ['rtos',['RTOS',['../class_r_t_o_s.html',1,'']]],
  ['run',['run',['../class_r_t_o_s.html#a27731fa3169d3337e826ff0c9994c384',1,'RTOS']]],
  ['run_5ftime',['run_time',['../class_r_t_o_s.html#a543dc322355f7277b027a3120ca13853',1,'RTOS']]]
];
