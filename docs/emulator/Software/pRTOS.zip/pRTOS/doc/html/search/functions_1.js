var searchData=
[
  ['display_5fstatistics',['display_statistics',['../class_r_t_o_s.html#ace9fc0f1b35c1383b1050222706f3b70',1,'RTOS']]]
];
