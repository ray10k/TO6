var searchData=
[
  ['ignore_5factivation_5ftime',['ignore_activation_time',['../class_r_t_o_s_1_1task.html#a0ea383a40c40d9f69fe8e29fb36fa40d',1,'RTOS::task']]],
  ['interval',['interval',['../class_r_t_o_s_1_1clock.html#a3ea95e4a1ed3507186493a8f2a7d76ac',1,'RTOS::clock']]],
  ['is_5fblocked',['is_blocked',['../class_r_t_o_s_1_1task.html#a1e0b2566b673b0e4e6efd63a80284d35',1,'RTOS::task']]],
  ['is_5fready',['is_ready',['../class_r_t_o_s_1_1task.html#a8ec666474a7668f78da3438dfa818a8e',1,'RTOS::task']]],
  ['is_5fsuspended',['is_suspended',['../class_r_t_o_s_1_1task.html#ab02fe6432956956957bb2629dc9a3031',1,'RTOS::task']]]
];
